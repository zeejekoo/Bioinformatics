"""
utils.py
Needleman-Wunsch와 Smith-Waterman 알고리즘에서 공통으로 사용되는 유틸리티 함수들
"""

def read_fasta(filename):
    """
    FASTA 파일을 읽어서 서열들을 반환합니다.
    
    Args:
        filename (str): FASTA 파일 경로
    
    Returns:
        dict: {header: sequence} 형태의 딕셔너리
    """
    sequences = {}
    current_header = None
    current_sequence = []
    
    with open(filename, 'r') as file:
        for line in file:
            line = line.strip()
            if line.startswith('>'):
                # 이전 서열 저장
                if current_header is not None:
                    sequences[current_header] = ''.join(current_sequence)
                
                # 새로운 헤더 시작
                current_header = line[1:]  # '>' 제거
                current_sequence = []
            else:
                # 서열 라인
                current_sequence.append(line)
        
        # 마지막 서열 저장
        if current_header is not None:
            sequences[current_header] = ''.join(current_sequence)
    
    return sequences


def get_substitution_score(char1, char2, match_score=2, mismatch_score=-1):
    """
    두 문자 간의 치환 스코어를 반환합니다.
    
    Args:
        char1 (str): 첫 번째 문자
        char2 (str): 두 번째 문자
        match_score (int): 매치 스코어
        mismatch_score (int): 미스매치 스코어
    
    Returns:
        int: 치환 스코어
    """
    if char1 == char2:
        return match_score
    else:
        return mismatch_score


def print_matrix(matrix, seq1="", seq2="", title="Matrix"):
    """
    매트릭스를 보기 좋게 출력합니다.
    
    Args:
        matrix (list): 2D 매트릭스
        seq1 (str): 첫 번째 서열 (행 라벨)
        seq2 (str): 두 번째 서열 (열 라벨)
        title (str): 매트릭스 제목
    """
    print(f"\n=== {title} ===")
    
    # 열 헤더 출력
    print("     ", end="")
    if seq2:
        print("    -", end="")
        for char in seq2:
            print(f"    {char}", end="")
    print()
    
    # 매트릭스 출력
    for i, row in enumerate(matrix):
        if seq1 and i > 0:
            print(f"  {seq1[i-1]} ", end="")
        elif i == 0:
            print("  - ", end="")
        else:
            print("    ", end="")
        
        for val in row:
            print(f"{val:5d}", end="")
        print()


def print_alignment(seq1_aligned, seq2_aligned, title="Alignment"):
    """
    정렬 결과를 보기 좋게 출력합니다.
    
    Args:
        seq1_aligned (str): 정렬된 첫 번째 서열
        seq2_aligned (str): 정렬된 두 번째 서열
        title (str): 정렬 제목
    """
    print(f"\n=== {title} ===")
    
    # 60개 문자씩 나누어 출력
    line_length = 60
    for i in range(0, len(seq1_aligned), line_length):
        end_pos = min(i + line_length, len(seq1_aligned))
        
        seq1_part = seq1_aligned[i:end_pos]
        seq2_part = seq2_aligned[i:end_pos]
        
        # 매치/미스매치 표시
        match_line = ""
        for j in range(len(seq1_part)):
            if seq1_part[j] == seq2_part[j]:
                if seq1_part[j] == '-':
                    match_line += " "
                else:
                    match_line += "|"
            else:
                match_line += " "
        
        print(f"Seq1: {seq1_part}")
        print(f"      {match_line}")
        print(f"Seq2: {seq2_part}")
        print()


def calculate_alignment_stats(seq1_aligned, seq2_aligned):
    """
    정렬 통계를 계산합니다.
    
    Args:
        seq1_aligned (str): 정렬된 첫 번째 서열
        seq2_aligned (str): 정렬된 두 번째 서열
    
    Returns:
        dict: 정렬 통계 정보
    """
    matches = 0
    mismatches = 0
    gaps = 0
    
    for i in range(len(seq1_aligned)):
        if seq1_aligned[i] == '-' or seq2_aligned[i] == '-':
            gaps += 1
        elif seq1_aligned[i] == seq2_aligned[i]:
            matches += 1
        else:
            mismatches += 1
    
    total_length = len(seq1_aligned)
    identity = (matches / total_length) * 100 if total_length > 0 else 0
    
    return {
        'matches': matches,
        'mismatches': mismatches,
        'gaps': gaps,
        'total_length': total_length,
        'identity': identity
    }