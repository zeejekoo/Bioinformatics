#!/usr/bin/env python3
"""
main.py
Needleman-Wunsch와 Smith-Waterman 알고리즘을 실행하는 메인 프로그램
"""

import sys
import argparse
from utils import read_fasta
from Needleman import NeedlemanWunsch
from Smith import SmithWaterman


def main():
    """
    메인 함수: command-line arguments를 처리하고 정렬 알고리즘을 실행합니다.
    """
    parser = argparse.ArgumentParser(
        description="Needleman-Wunsch 및 Smith-Waterman 정렬 알고리즘 실행",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
사용 예시:
  python3 main.py ref.fasta query.fasta -g -2
  python3 main.py ref.fasta query.fasta --gap -1 -v
  python3 main.py ref.fasta query.fasta --indel -2
  python3 main.py ref.fasta query.fasta -g -1 --indel -3
  python3 main.py ref.fasta query.fasta -g -1 --algorithm needleman
        """
    )
    
    parser.add_argument("reference_fasta", help="Reference 서열이 들어있는 FASTA 파일")
    parser.add_argument("query_fasta", help="Query 서열이 들어있는 FASTA 파일")
    parser.add_argument("-g", "--gap", type=int, default=-1, 
                       help="Gap penalty (기본값: -1)")
    parser.add_argument("--indel", type=int, default=None,
                       help="Indel penalty (기본값: gap과 동일)")
    parser.add_argument("-a", "--algorithm", choices=['needleman', 'smith', 'both'],
                       default='both', help="실행할 알고리즘 (기본값: both)")
    parser.add_argument("-v", "--verbose", action="store_true",
                       help="상세 출력 (매트릭스 포함)")
    
    # 인수가 없으면 도움말 출력
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)
    
    args = parser.parse_args()
    
    # Indel 스코어 설정 (indel 파라미터가 지정되지 않으면 gap penalty 사용)
    indel_penalty = args.indel if args.indel is not None else args.gap
    
    # Match/Mismatch 스코어는 고정값 사용
    match_score = 2
    mismatch_score = -1
    
    # FASTA 파일 읽기
    print("Reading FASTA files...")
    reference_sequences = read_fasta(args.reference_fasta)
    query_sequences = read_fasta(args.query_fasta)
    
    print(f"Reference sequences: {len(reference_sequences)}")
    for header in reference_sequences:
        print(f"  - {header}: {len(reference_sequences[header])} bp")
    
    print(f"Query sequences: {len(query_sequences)}")
    for header in query_sequences:
        print(f"  - {header}: {len(query_sequences[header])} bp")
    
    # 각 reference와 query 조합에 대해 정렬 수행
    for ref_header, ref_seq in reference_sequences.items():
        for query_header, query_seq in query_sequences.items():
            
            print(f"\n{'='*80}")
            print(f"ALIGNING: {ref_header} vs {query_header}")
            print(f"{'='*80}")
            
            # Needleman-Wunsch 알고리즘 실행
            if args.algorithm in ['needleman', 'both']:
                needleman = NeedlemanWunsch(
                    match_score=match_score,
                    mismatch_score=mismatch_score,
                    gap_penalty=args.gap,
                    indel_penalty=indel_penalty
                )
                
                needleman_result = needleman.align(ref_seq, query_seq, verbose=args.verbose)
            
            # Smith-Waterman 알고리즘 실행
            if args.algorithm in ['smith', 'both']:
                smith = SmithWaterman(
                    match_score=match_score,
                    mismatch_score=mismatch_score,
                    gap_penalty=args.gap,
                    indel_penalty=indel_penalty
                )
                
                smith_result = smith.align(ref_seq, query_seq, verbose=args.verbose)
            
            # 결과 비교 (both 모드일 때)
            if args.algorithm == 'both':
                print(f"\n{'='*60}")
                print(f"ALGORITHM COMPARISON")
                print(f"{'='*60}")
                print(f"Needleman-Wunsch (Global) Score: {needleman_result['score']}")
                print(f"Smith-Waterman (Local) Score: {smith_result['score']}")
                print(f"Global Alignment Length: {needleman_result['stats']['total_length']}")
                print(f"Local Alignment Length: {smith_result['stats']['total_length']}")
                print(f"Global Identity: {needleman_result['stats']['identity']:.1f}%")
                print(f"Local Identity: {smith_result['stats']['identity']:.1f}%")


def create_sample_fasta():
    """
    테스트용 샘플 FASTA 파일들을 생성합니다.
    """
    # Reference FASTA 파일
    ref_content = """>reference_seq1
ACGTACGTACGT
>reference_seq2
ATCGATCGATCG
"""
    
    # Query FASTA 파일  
    query_content = """>query_seq1
ACGTACCGTACGT
>query_seq2
ATCGTTCGATCG
"""
    
    with open("sample_ref.fasta", "w") as f:
        f.write(ref_content)
    
    with open("sample_query.fasta", "w") as f:
        f.write(query_content)
    
    print("Sample FASTA files created:")
    print("  - sample_ref.fasta")
    print("  - sample_query.fasta")


if __name__ == "__main__":
    # 샘플 파일이 없으면 생성
    import os
    if not os.path.exists("sample_ref.fasta") or not os.path.exists("sample_query.fasta"):
        print("Creating sample FASTA files...")
        create_sample_fasta()
        print()
    
    main()