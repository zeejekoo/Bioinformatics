"""
Smith.py
Smith-Waterman 로컬 정렬 알고리즘 구현
"""

from utils import get_substitution_score, print_matrix, print_alignment, calculate_alignment_stats


class SmithWaterman:
    """
    Smith-Waterman 로컬 정렬 알고리즘을 구현하는 클래스
    """
    
    def __init__(self, match_score=2, mismatch_score=-1, gap_penalty=-1, indel_penalty=None):
        """
        SmithWaterman 객체를 초기화합니다.
        
        Args:
            match_score (int): 매치 스코어
            mismatch_score (int): 미스매치 스코어
            gap_penalty (int): 갭 페널티
            indel_penalty (int): indel 페널티 (None이면 gap_penalty 사용)
        """
        self.match_score = match_score
        self.mismatch_score = mismatch_score
        self.gap_penalty = gap_penalty
        self.indel_penalty = indel_penalty if indel_penalty is not None else gap_penalty
        self.score_matrix = None
        self.traceback_matrix = None
        self.max_score = 0
        self.max_i = 0
        self.max_j = 0
    
    
    def initialize_matrix(self, seq1, seq2):
        """
        스코어 매트릭스와 트레이스백 매트릭스를 초기화합니다.
        
        Args:
            seq1 (str): 첫 번째 서열
            seq2 (str): 두 번째 서열
        """
        rows = len(seq1) + 1
        cols = len(seq2) + 1
        
        # 스코어 매트릭스 초기화 (모두 0으로)
        self.score_matrix = [[0 for _ in range(cols)] for _ in range(rows)]
        
        # 트레이스백 매트릭스 초기화
        self.traceback_matrix = [['' for _ in range(cols)] for _ in range(rows)]
        
        # 최대 스코어 초기화
        self.max_score = 0
        self.max_i = 0
        self.max_j = 0
    
    
    def fill_matrix(self, seq1, seq2):
        """
        다이나믹 프로그래밍을 사용하여 스코어 매트릭스를 채웁니다.
        
        Args:
            seq1 (str): 첫 번째 서열
            seq2 (str): 두 번째 서열
        """
        for i in range(1, len(seq1) + 1):
            for j in range(1, len(seq2) + 1):
                # 세 가지 경우의 스코어 계산
                match_score = (self.score_matrix[i-1][j-1] + 
                              get_substitution_score(seq1[i-1], seq2[j-1], 
                                                   self.match_score, self.mismatch_score))
                delete_score = self.score_matrix[i-1][j] + self.indel_penalty
                insert_score = self.score_matrix[i][j-1] + self.indel_penalty
                
                # 최대 스코어 선택 (0보다 작으면 0)
                max_score = max(0, match_score, delete_score, insert_score)
                self.score_matrix[i][j] = max_score
                
                # 트레이스백 방향 저장
                if max_score == 0:
                    self.traceback_matrix[i][j] = 'S'  # 시작점
                elif max_score == match_score:
                    self.traceback_matrix[i][j] = 'D'  # 대각선
                elif max_score == delete_score:
                    self.traceback_matrix[i][j] = 'U'  # 위
                else:
                    self.traceback_matrix[i][j] = 'L'  # 왼쪽
                
                # 최대 스코어 위치 업데이트
                if max_score > self.max_score:
                    self.max_score = max_score
                    self.max_i = i
                    self.max_j = j
    
    
    def traceback(self, seq1, seq2):
        """
        트레이스백을 수행하여 최적 로컬 정렬을 찾습니다.
        
        Args:
            seq1 (str): 첫 번째 서열
            seq2 (str): 두 번째 서열
        
        Returns:
            tuple: (정렬된 seq1, 정렬된 seq2, 시작 위치들, 끝 위치들)
        """
        aligned_seq1 = ""
        aligned_seq2 = ""
        
        i = self.max_i
        j = self.max_j
        
        # 최대 스코어 위치에서 시작
        while i > 0 and j > 0 and self.score_matrix[i][j] > 0:
            if self.traceback_matrix[i][j] == 'D':
                # 대각선 이동 (매치/미스매치)
                aligned_seq1 = seq1[i-1] + aligned_seq1
                aligned_seq2 = seq2[j-1] + aligned_seq2
                i -= 1
                j -= 1
            elif self.traceback_matrix[i][j] == 'U':
                # 위로 이동 (seq1에서 삭제, seq2에 갭)
                aligned_seq1 = seq1[i-1] + aligned_seq1
                aligned_seq2 = '-' + aligned_seq2
                i -= 1
            elif self.traceback_matrix[i][j] == 'L':
                # 왼쪽 이동 (seq2에서 삭제, seq1에 갭)
                aligned_seq1 = '-' + aligned_seq1
                aligned_seq2 = seq2[j-1] + aligned_seq2
                j -= 1
            else:
                # 스코어가 0이 되면 종료
                break
        
        return aligned_seq1, aligned_seq2, (i, j), (self.max_i-1, self.max_j-1)
    
    
    def align(self, seq1, seq2, verbose=False):
        """
        두 서열을 로컬 정렬합니다.
        
        Args:
            seq1 (str): 첫 번째 서열
            seq2 (str): 두 번째 서열
            verbose (bool): 상세 출력 여부
        
        Returns:
            dict: 정렬 결과와 통계
        """
        print(f"\n{'='*60}")
        print(f"SMITH-WATERMAN LOCAL ALIGNMENT")
        print(f"{'='*60}")
        print(f"Sequence 1: {seq1}")
        print(f"Sequence 2: {seq2}")
        print(f"Match score: {self.match_score}")
        print(f"Mismatch score: {self.mismatch_score}")
        print(f"Gap penalty: {self.gap_penalty}")
        print(f"Indel penalty: {self.indel_penalty}")
        
        # 매트릭스 초기화 및 채우기
        self.initialize_matrix(seq1, seq2)
        self.fill_matrix(seq1, seq2)
        
        # 상세 출력
        if verbose:
            print_matrix(self.score_matrix, seq1, seq2, "Score Matrix")
        
        # 트레이스백 수행
        aligned_seq1, aligned_seq2, start_pos, end_pos = self.traceback(seq1, seq2)
        
        # 정렬 결과 출력
        print_alignment(aligned_seq1, aligned_seq2, "Local Alignment Result")
        
        # 통계 계산
        stats = calculate_alignment_stats(aligned_seq1, aligned_seq2)
        
        print(f"\n=== Alignment Statistics ===")
        print(f"Max Alignment Score: {self.max_score}")
        print(f"Alignment Length: {stats['total_length']}")
        print(f"Matches: {stats['matches']}")
        print(f"Mismatches: {stats['mismatches']}")
        print(f"Gaps: {stats['gaps']}")
        print(f"Identity: {stats['identity']:.1f}%")
        print(f"Seq1 aligned region: {start_pos[0]} - {end_pos[0]} (length: {end_pos[0] - start_pos[0] + 1})")
        print(f"Seq2 aligned region: {start_pos[1]} - {end_pos[1]} (length: {end_pos[1] - start_pos[1] + 1})")
        
        return {
            'aligned_seq1': aligned_seq1,
            'aligned_seq2': aligned_seq2,
            'score': self.max_score,
            'start_pos': start_pos,
            'end_pos': end_pos,
            'stats': stats
        }